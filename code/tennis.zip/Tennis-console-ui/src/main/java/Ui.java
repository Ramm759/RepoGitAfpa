import com.afpa.tennis.controller.*;

public class Ui {
    public static void main(String[] args) {
        // JoueurController joueurController = new JoueurController();
        // joueurController.afficheDetailsJoueur();
        // joueurController.creerJoueur();
        // joueurController.renomme();
        // joueurController.changeSexe();
        // joueurController.deleteJoueur();


        // TournoiController tournoiController = new TournoiController();
        // tournoiController.afficheDetailsTournoi();
        // tournoiController.creerTournoi();
        // tournoiController.deleteTournoi();

        EpreuveController epreuveController = new EpreuveController();
        epreuveController.afficheDetailsEpreuve();
        // epreuveController.afficheRollandGarros();

        // MatchController matchController = new MatchController();
        //matchController.afficheDetailsMatch();

        // ScoreController scoreController = new ScoreController();
        // scoreController.afficheDetailsScore();
    }
}
