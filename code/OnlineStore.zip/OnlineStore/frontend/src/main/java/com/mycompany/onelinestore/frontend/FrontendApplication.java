package com.mycompany.onelinestore.frontend;

public class FrontendApplication {
    public static void main(String[] args) {

    }
}
