package com.mycompany.onlinestore.backend;

public class Backendapplication {
    public static void main(String[] args) {

    }
}
