package com.mycompany.onlinestore.backend.entity;

import java.util.HashSet;

public class Catalogue {
    public static HashSet<Work> listOfWorks = new HashSet();
}
