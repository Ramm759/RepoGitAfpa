package com.mycompany.geometrie.backend.controller;

public class MainController {
    public String askOperation(){
        return "surface";

    }

    public void askPaint(){

    }

}
