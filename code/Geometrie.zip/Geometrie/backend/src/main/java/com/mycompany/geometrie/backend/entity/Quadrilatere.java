package com.mycompany.geometrie.backend.entity;

public class Quadrilatere {

}
