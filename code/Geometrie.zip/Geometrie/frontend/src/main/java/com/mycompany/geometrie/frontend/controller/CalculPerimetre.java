package com.mycompany.geometrie.frontend.controller;

import javax.servlet.http.HttpServlet;

public class CalculPerimetre extends HttpServlet {
}
